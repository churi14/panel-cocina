"use client";
import React, { useState, useEffect } from 'react';
import { 
  Beef, Truck, BookOpen, Droplet, LogOut, Scale,
  UtensilsCrossed, ChevronRight, PackageMinus, X, Carrot, Wine, Sandwich, Wheat, Soup,
  Plus, Trash2, Calculator, CheckCircle2, Clock, AlertCircle, ArrowLeft, Play, Square, CheckSquare,
  Search, Phone, MapPin, Mail, Calendar as CalendarIcon, FileText, User, Edit, List, BarChart3, Download
} from 'lucide-react';
import type { Ingredient, Recipe, ProductionRecord, Supplier } from '../types';

export default function KitchenProductionModal({ onClose, activeProduction, setActiveProduction, recipesDB, setProductionHistory }: any) {
    const [view, setView] = useState<'category' | 'product' | 'recipe'>(activeProduction ? 'recipe' : 'category');
    const [selectedCategory, setSelectedCategory] = useState("");
    const [selectedProduct, setSelectedProduct] = useState<any>(null);
    const [targetUnits, setTargetUnits] = useState(0); 
    const [currentTime, setCurrentTime] = useState(Date.now());
    const [checkedIngredients, setCheckedIngredients] = useState<Set<number>>(new Set());

    const groupedRecipes = recipesDB.reduce((acc:any, recipe:Recipe) => {
        if (!acc[recipe.category]) acc[recipe.category] = [];
        acc[recipe.category].push(recipe);
        return acc;
    }, {});

    useEffect(() => {
        if (activeProduction && !selectedProduct) {
            const found = recipesDB.find((r: Recipe) => r.name === activeProduction.recipeName);
            if (found) {
                setSelectedProduct(found);
                setTargetUnits(activeProduction.targetUnits);
                setCheckedIngredients(new Set(found.ingredients.map((_:any, i:number) => i)));
            }
        }
        const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
        return () => clearInterval(timer);
    }, [activeProduction]);

    const handleProductSelect = (product: any) => { setSelectedProduct(product); setTargetUnits(product.baseYield); setView('recipe'); setCheckedIngredients(new Set()); };
    const toggleCheck = (idx: number) => { if(activeProduction) return; const next = new Set(checkedIngredients); if (next.has(idx)) next.delete(idx); else next.add(idx); setCheckedIngredients(next); };
    const allIngredientsChecked = selectedProduct && checkedIngredients.size === selectedProduct.ingredients.length;
    const canStart = targetUnits > 0 && allIngredientsChecked;
    const handleStart = () => { if (!canStart) return; setActiveProduction({ recipeName: selectedProduct.name, targetUnits: targetUnits, unit: selectedProduct.unit, startTime: Date.now(), status: 'running' }); };
    const handleFinish = () => {
        const endTime = Date.now();
        const durationSeconds = (endTime - activeProduction.startTime) / 1000;
        const newRecord = { id: Date.now(), date: new Date().toLocaleDateString(), timestamp: endTime, recipeName: activeProduction.recipeName, quantity: activeProduction.targetUnits, unit: activeProduction.unit, durationSeconds: durationSeconds, startTime: new Date(activeProduction.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}), endTime: new Date(endTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) };
        setProductionHistory((prev: ProductionRecord[]) => [...prev, newRecord]);
        alert(`Producción Finalizada y Guardada.`);
        setActiveProduction(null);
        onClose();
    };
    const multiplier = selectedProduct && targetUnits > 0 ? targetUnits / selectedProduct.baseYield : 0;
    const elapsedTime = activeProduction ? currentTime - activeProduction.startTime : 0;
    const formatTimer = (ms: number) => { const totalSecs = Math.floor(ms / 1000); const hrs = Math.floor(totalSecs / 3600); const mins = Math.floor((totalSecs % 3600) / 60); const secs = totalSecs % 60; return `${hrs > 0 ? hrs + ':' : ''}${mins.toString().padStart(2,'0')}:${secs.toString().padStart(2,'0')}`; };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl h-[90vh] flex flex-col overflow-hidden">
                <div className="px-8 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <div><h2 className="text-xl font-bold text-slate-800 flex items-center gap-2"><UtensilsCrossed className="text-amber-600" /> Cocina General</h2><p className="text-slate-500 text-sm">{activeProduction ? 'Producción en curso...' : (view === 'recipe' ? `Configurando: ${selectedProduct.name}` : 'Seleccione receta')}</p></div>
                    <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X size={24} className="text-slate-500" /></button>
                </div>
                <div className="flex-1 overflow-y-auto bg-slate-50 p-8">
                    {view === 'category' && !activeProduction && (<div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full content-center"><button onClick={() => { setSelectedCategory('Panificados'); setView('product'); }} className="flex flex-col items-center justify-center p-10 bg-white border-2 border-amber-100 rounded-3xl hover:border-amber-400 hover:shadow-xl transition-all group"><Wheat size={48} className="text-amber-600 mb-4 group-hover:scale-110 transition-transform"/> <span className="text-2xl font-bold text-slate-800">Panificados</span></button><button onClick={() => { setSelectedCategory('Salsas'); setView('product'); }} className="flex flex-col items-center justify-center p-10 bg-white border-2 border-red-100 rounded-3xl hover:border-red-400 hover:shadow-xl transition-all group"><Droplet size={48} className="text-red-600 mb-4 group-hover:scale-110 transition-transform"/> <span className="text-2xl font-bold text-slate-800">Salsas</span></button><button onClick={() => { setSelectedCategory('Prep'); setView('product'); }} className="flex flex-col items-center justify-center p-10 bg-white border-2 border-blue-100 rounded-3xl hover:border-blue-400 hover:shadow-xl transition-all group"><Clock size={48} className="text-blue-600 mb-4 group-hover:scale-110 transition-transform"/> <span className="text-2xl font-bold text-slate-800">Prep / Otros</span></button></div>)}
                    {view === 'product' && !activeProduction && (<div className="space-y-6"><button onClick={() => setView('category')} className="text-sm font-bold text-slate-400 hover:text-slate-600 flex items-center gap-1"><ArrowLeft size={16}/> Volver</button><div className="grid grid-cols-2 md:grid-cols-4 gap-4">{groupedRecipes[selectedCategory]?.map((prod: any) => (<button key={prod.id} onClick={() => handleProductSelect(prod)} className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-amber-500 hover:shadow-md transition-all text-left group"><h3 className="font-bold text-lg text-slate-800 mb-1 group-hover:text-amber-600 transition-colors">{prod.name}</h3><p className="text-xs text-slate-500">Receta base: {prod.baseYield} {prod.unit}</p>{prod.warning && <span className="inline-block mt-2 px-2 py-1 bg-blue-100 text-blue-700 text-[10px] font-bold rounded">{prod.warning}</span>}</button>))}</div></div>)}
                    {view === 'recipe' && selectedProduct && (<div className="flex flex-col h-full">{!activeProduction && <button onClick={() => setView('product')} className="text-sm font-bold text-slate-400 hover:text-slate-600 flex items-center gap-1 mb-4"><ArrowLeft size={16}/> Volver</button>}<div className="flex flex-1 gap-8"><div className="w-1/3 bg-white p-6 rounded-2xl border border-slate-200 flex flex-col shadow-sm"><h3 className="font-bold text-slate-400 uppercase text-xs mb-6 tracking-wider">{activeProduction ? 'Estado Actual' : 'Planificación'}</h3><div className="mb-8"><label className="block text-sm font-bold text-slate-600 mb-2">Cantidad a Producir</label><div className="relative"><input type="number" value={targetUnits} disabled={!!activeProduction} onChange={(e) => setTargetUnits(Math.max(0, Number(e.target.value)))} className={`w-full p-4 border-2 rounded-xl text-4xl font-black text-center outline-none transition-all ${activeProduction ? 'bg-slate-100 border-slate-200 text-slate-500' : 'bg-slate-50 border-amber-200 text-amber-600 focus:border-amber-500 focus:bg-white'}`} /><span className="absolute right-4 top-6 text-sm font-bold text-slate-300 uppercase">{selectedProduct.unit}</span></div></div>{activeProduction && (<div className="mt-auto mb-6 bg-slate-900 rounded-2xl p-6 text-center shadow-inner border border-slate-700 relative overflow-hidden"><div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-500 to-blue-500 animate-pulse"></div><span className="text-slate-400 text-xs font-bold uppercase tracking-widest block mb-2">Tiempo Transcurrido</span><span className="text-5xl font-mono font-bold text-white tracking-widest">{formatTimer(elapsedTime)}</span></div>)}{selectedProduct.warning && (<div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex items-start gap-3 mt-auto"><AlertCircle className="text-blue-500 shrink-0" size={20}/><div><h4 className="font-bold text-blue-700 text-xs uppercase">Recordatorio</h4><p className="text-sm text-blue-600 leading-tight">{selectedProduct.warning}</p></div></div>)}</div><div className="w-2/3 flex flex-col"><div className="bg-white rounded-2xl border border-slate-200 flex-1 flex flex-col overflow-hidden shadow-sm"><div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center"><h3 className="font-bold text-slate-700 flex items-center gap-2"><Calculator size={18}/> Checklist de Insumos</h3><span className="text-xs font-bold text-slate-400 uppercase">Para {targetUnits} {selectedProduct.unit}</span></div><div className="flex-1 overflow-y-auto p-0"><table className="w-full text-sm"><thead className="bg-slate-50 text-slate-400 text-xs uppercase font-bold"><tr><th className="py-3 pl-6 text-left w-12">Check</th><th className="py-3 text-left">Ingrediente</th><th className="py-3 pr-6 text-right">Cantidad</th></tr></thead><tbody className="divide-y divide-slate-100">{selectedProduct.ingredients.map((ing: any, idx: number) => { const isChecked = checkedIngredients.has(idx); return (<tr key={idx} className={`transition-colors cursor-pointer ${isChecked ? 'bg-green-50/50' : 'hover:bg-slate-50'}`} onClick={() => toggleCheck(idx)}><td className="py-4 pl-6">{isChecked ? <CheckSquare className="text-green-500" size={20}/> : <Square className="text-slate-300" size={20}/>}</td><td className={`py-4 font-medium ${isChecked ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{ing.name}</td><td className={`py-4 pr-6 text-right font-bold text-lg ${isChecked ? 'text-slate-400' : 'text-slate-900'}`}>{(ing.qty * multiplier).toFixed(3)} <span className="text-sm font-medium text-slate-400">{ing.unit}</span></td></tr>); })}</tbody></table></div><div className="p-6 border-t border-slate-200 bg-slate-50">{!activeProduction ? (<button onClick={handleStart} disabled={!canStart} className={`w-full py-4 font-bold rounded-xl text-lg transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 ${canStart ? 'bg-green-600 text-white hover:bg-green-500' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`} > {allIngredientsChecked ? <><Play size={20} fill="currentColor"/> INICIAR PRODUCCIÓN (TIMER)</> : `FALTAN CHECKS (${selectedProduct.ingredients.length - checkedIngredients.size})`} </button>) : (<button onClick={handleFinish} className="w-full py-4 bg-slate-900 text-white font-bold rounded-xl text-lg hover:bg-slate-800 transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2"><CheckCircle2 size={20}/> FINALIZAR Y GUARDAR</button>)}</div></div></div></div></div>)}
                </div>
            </div>
        </div>
    );
}

// -------------------------------------------------------------------------