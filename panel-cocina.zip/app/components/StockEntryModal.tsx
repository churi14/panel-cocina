"use client";

import React, { useState, useEffect } from 'react';
import { X, Truck, Check, ChevronLeft, Search, RefreshCw } from 'lucide-react';
import { supabase } from '../supabase';

type StockItem = { id: number; nombre: string; categoria: string; cantidad: number; unidad: string; };

const CATEGORIES = [
  { id: 'CARNES',       label: 'Carnicería',   emoji: '🥩', color: 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100' },
  { id: 'SECOS',        label: 'Insumos/Secos', emoji: '🧂', color: 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100' },
  { id: 'VERDURA',      label: 'Verduras',     emoji: '🥗', color: 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100' },
  { id: 'FIAMBRE',      label: 'Fiambres',     emoji: '🧀', color: 'bg-pink-50 text-pink-700 border-pink-200 hover:bg-pink-100' },
  { id: 'BEBIDAS',      label: 'Bebidas',      emoji: '🥤', color: 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100' },
  { id: 'LIMPIEZA',     label: 'Limpieza',     emoji: '🧴', color: 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100' },
  { id: 'BROLAS',       label: 'Brolas',       emoji: '🍫', color: 'bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100' },
  { id: 'DESCARTABLES', label: 'Descartables', emoji: '📦', color: 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100' },
];

export default function StockEntryModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<'cat' | 'product' | 'form'>('cat');
  const [selectedCat, setSelectedCat] = useState<typeof CATEGORIES[0] | null>(null);
  const [products, setProducts] = useState<StockItem[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<StockItem | null>(null);
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Form fields
  const [cantidad, setCantidad] = useState('');
  const [unidad, setUnidad] = useState<'kg' | 'u' | 'lt'>('kg');
  const [lote, setLote] = useState('');
  const [hasVenc, setHasVenc] = useState(false);
  const [fechaVenc, setFechaVenc] = useState('');

  const fetchProducts = async (catId: string) => {
    setLoadingProducts(true);
    const { data } = await supabase
      .from('stock')
      .select('*')
      .eq('categoria', catId)
      .order('nombre');
    setProducts(data ?? []);
    setLoadingProducts(false);
  };

  const handleSelectCat = (cat: typeof CATEGORIES[0]) => {
    setSelectedCat(cat);
    setSearch('');
    fetchProducts(cat.id);
    setStep('product');
  };

  const handleSelectProduct = (product: StockItem) => {
    setSelectedProduct(product);
    setUnidad(product.unidad as 'kg' | 'u' | 'lt');
    setStep('form');
  };

  const handleConfirm = async () => {
    if (!selectedProduct || !cantidad) return;
    setSaving(true);
    const newQty = selectedProduct.cantidad + parseFloat(cantidad.replace(',', '.'));
    const update: any = {
      cantidad: newQty,
      fecha_actualizacion: new Date().toISOString().slice(0, 10),
    };
    if (hasVenc && fechaVenc) update.fecha_vencimiento = fechaVenc;

    await supabase.from('stock').update(update).eq('id', selectedProduct.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 1200);
  };

  const filteredProducts = products.filter(p =>
    p.nombre.toLowerCase().includes(search.toLowerCase())
  );

  const catConfig = selectedCat ?? CATEGORIES[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in zoom-in-95 duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">

        {/* HEADER */}
        <div className="px-8 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50 shrink-0">
          <div className="flex items-center gap-3">
            {step !== 'cat' && (
              <button onClick={() => { setStep(step === 'form' ? 'product' : 'cat'); setSelectedProduct(null); }}
                className="p-2 hover:bg-slate-200 rounded-full transition-colors">
                <ChevronLeft size={20} className="text-slate-500" />
              </button>
            )}
            <div>
              <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <Truck className="text-blue-600" size={20} /> Cargar Stock / Facturas
              </h2>
              <p className="text-slate-400 text-xs">
                {step === 'cat' ? 'Elegí la categoría' :
                 step === 'product' ? `${catConfig.emoji} ${catConfig.label} — Elegí el producto` :
                 `${catConfig.emoji} ${selectedProduct?.nombre}`}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X size={22} className="text-slate-500" />
          </button>
        </div>

        {/* CONTENIDO */}
        <div className="flex-1 overflow-y-auto p-8">

          {/* PASO 1: CATEGORÍAS */}
          {step === 'cat' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {CATEGORIES.map(cat => (
                <button key={cat.id} onClick={() => handleSelectCat(cat)}
                  className={`flex flex-col items-center justify-center p-6 rounded-2xl border-2 transition-all active:scale-95 hover:shadow-md ${cat.color}`}>
                  <span className="text-4xl mb-3">{cat.emoji}</span>
                  <span className="font-bold text-sm uppercase">{cat.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* PASO 2: PRODUCTOS */}
          {step === 'product' && (
            <div>
              <div className="relative mb-5">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar producto..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  autoFocus
                  className="w-full pl-9 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-400 transition-colors"
                />
              </div>

              {loadingProducts ? (
                <div className="flex items-center justify-center py-12">
                  <RefreshCw size={28} className="text-slate-300 animate-spin" />
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {filteredProducts.map(product => (
                    <button key={product.id} onClick={() => handleSelectProduct(product)}
                      className="text-left p-4 rounded-2xl border-2 border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-all active:scale-95 group">
                      <p className="font-black text-slate-800 text-sm leading-tight mb-1 group-hover:text-blue-700">{product.nombre}</p>
                      <p className="text-xs text-slate-400 font-medium">
                        Stock actual: <span className="font-bold text-slate-600">
                          {product.cantidad > 0 ? `${product.cantidad} ${product.unidad}` : 'Sin stock'}
                        </span>
                      </p>
                    </button>
                  ))}
                  {filteredProducts.length === 0 && (
                    <div className="col-span-3 text-center py-8 text-slate-400">No se encontraron productos</div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* PASO 3: FORMULARIO */}
          {step === 'form' && selectedProduct && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Izquierda: cantidad */}
              <div className="space-y-6">
                {/* Stock actual */}
                <div className={`px-5 py-4 rounded-2xl border-2 ${catConfig.color}`}>
                  <p className="text-xs font-black uppercase mb-1 opacity-70">Stock actual</p>
                  <p className="text-3xl font-black">
                    {selectedProduct.cantidad > 0
                      ? `${selectedProduct.cantidad} ${selectedProduct.unidad}`
                      : 'Sin stock'}
                  </p>
                </div>

                {/* Cantidad a agregar */}
                <div>
                  <label className="block text-xs font-black text-slate-500 uppercase mb-2">Cantidad a agregar</label>
                  <div className="relative">
                    <input
                      type="number" inputMode="decimal" step="0.01"
                      placeholder="0,00"
                      value={cantidad}
                      onChange={e => setCantidad(e.target.value)}
                      autoFocus
                      className="w-full p-5 bg-slate-50 border-2 border-slate-200 rounded-2xl text-5xl font-black text-center text-blue-600 outline-none focus:border-blue-400 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {/* Unidad */}
                <div>
                  <label className="block text-xs font-black text-slate-500 uppercase mb-2">Unidad</label>
                  <div className="flex bg-slate-100 p-1 rounded-xl gap-1">
                    {(['kg', 'u', 'lt'] as const).map(u => (
                      <button key={u} onClick={() => setUnidad(u)}
                        className={`flex-1 py-3 rounded-lg text-sm font-black uppercase transition-all
                          ${unidad === u ? 'bg-white shadow text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}>
                        {u}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Derecha: trazabilidad */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-5">
                <h3 className="font-black text-slate-700 text-xs uppercase tracking-wider">Trazabilidad</h3>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Lote / Remito</label>
                  <input
                    type="text"
                    value={lote}
                    onChange={e => setLote(e.target.value)}
                    placeholder="Ej: R-12345"
                    className="w-full p-3 bg-white border border-slate-200 rounded-xl font-mono text-sm outline-none focus:border-blue-400 transition-colors"
                  />
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <label className="font-bold text-slate-700 text-sm">¿Tiene vencimiento?</label>
                    <button onClick={() => setHasVenc(!hasVenc)}
                      className={`w-12 h-6 rounded-full transition-all ${hasVenc ? 'bg-blue-600' : 'bg-slate-200'}`}>
                      <div className={`w-5 h-5 bg-white rounded-full shadow transition-all mx-0.5 ${hasVenc ? 'translate-x-6' : 'translate-x-0'}`} />
                    </button>
                  </div>
                  {hasVenc && (
                    <input type="date" value={fechaVenc} onChange={e => setFechaVenc(e.target.value)}
                      className="w-full p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl font-bold text-sm outline-none" />
                  )}
                </div>

                {/* Preview nuevo stock */}
                {cantidad && parseFloat(cantidad) > 0 && (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                    <p className="text-xs font-black text-green-600 uppercase mb-1">Nuevo stock</p>
                    <p className="text-3xl font-black text-green-700">
                      {(selectedProduct.cantidad + parseFloat(cantidad.replace(',', '.'))).toFixed(2)} {unidad}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* FOOTER */}
        {step === 'form' && (
          <div className="p-6 border-t border-slate-100 flex justify-end gap-3 bg-slate-50 shrink-0">
            <button onClick={() => { setStep('product'); setSelectedProduct(null); }}
              className="px-6 py-3 rounded-xl border-2 border-slate-300 font-bold text-slate-600 hover:bg-white transition-all">
              Atrás
            </button>
            <button
              onClick={handleConfirm}
              disabled={!cantidad || parseFloat(cantidad) <= 0 || saving || saved}
              className={`px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all min-w-36 justify-center
                ${saved ? 'bg-green-500 text-white' :
                  !cantidad || parseFloat(cantidad) <= 0 ? 'bg-slate-200 text-slate-400 cursor-not-allowed' :
                  'bg-blue-600 text-white hover:bg-blue-700 shadow-lg active:scale-95'}`}
            >
              {saved ? <><Check size={18} /> GUARDADO</> :
               saving ? <><RefreshCw size={18} className="animate-spin" /> Guardando...</> :
               <><Check size={18} /> CONFIRMAR</>}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}